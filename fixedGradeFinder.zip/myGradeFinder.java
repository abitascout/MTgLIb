
/**
 * calculates your grade
 * Input: a text file with one entry per line:
 *      [assignmentType] [grade]
 *      assignmentType = W (worksheet), E (exam), P (program)
 *      grade - an int
 *      separated by a space
 *
 * @author (Lori)
 * @version (2018)
 */
import java.io.*;
import java.util.*;

public class myGradeFinder
{
    public static void main (String[] args) throws IOException
    {
        //replace this file name with your own
        Scanner scan = new Scanner(new File("grades.txt"));
        
        //filling the list
        String line = "";
        Assignment a = null;
        List<Assignment> grades = new List<Assignment>();
        int count = 0;
        while(scan.hasNextLine())
        {
            line = scan.nextLine();
            String[] hold = line.split(" ");
            a = new Assignment(hold[0].charAt(0), Integer.parseInt(hold[1]));
            grades.InsertAfter(a);
            count++;
        }
        
        //calculate the grade
        grades.First();
        int numP = 0; int numE = 0; int numW = 0;
        int p = 0; int e = 0; int w = 0;
        for (int i = 0; i < count; i++)
        {
            a = grades.GetValue();
            if (a.getType() == 'p' || a.getType() == 'P') { numP++; p += a.getGrade();}
            else if (a.getType() == 'e' || a.getType() == 'E') { numE++; e += a.getGrade();}
            else if (a.getType() == 'w' || a.getType() == 'W') { numW++; w += a.getGrade();}
            grades.Next();
        }
        float pAvg = p/numP; float eAvg = e/numE; float wAvg = w/numW;
        float result = (pAvg * (float)0.5) + (eAvg * (float)0.4) + (wAvg * (float)0.1);
        System.out.println("Your grade so far is about " + result);
    }
}
