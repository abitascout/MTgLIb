
/**
 * holds individual assignments
 *
 * @author (Lori)
 * @version (2018)
 */
public class Assignment
{
    private int grade;
    private char type;

    public Assignment()
    { grade = 0; type = ' '; }
    
    public Assignment(char t, int g)
    { grade = g; type = t; }

    public void setGrade (int g)
    { grade = g; }
    
    public int getGrade()
    { return grade; }
    
    public void setType(char t)
    { type = t; }
    
    public char getType()
    { return type; }
}
